clc
close all
clear all
load('Figure_2c_2d.mat')
%%
xx=[datenum(2022,6,1):datenum(2022,9,30)];
xd1=datenum(2022,7,15)-datenum(2022,7,8)+1;
xd2=datenum(2022,8,23)-datenum(2022,8,2)+1;
%% 500hPa & mld thickness ano
subplot(212)
%
H_pa01 = patch([datenum(2022,6,30),datenum(2022,6,30),datenum(2022,7,8),datenum(2022,7,8)],...
    [-120,120,120,-120],mhwcolor);
set(H_pa01,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
H_pa02 = patch([datenum(2022,7,15),datenum(2022,7,15),datenum(2022,8,2),datenum(2022,8,2)],...
    [-120,120,120,-120],mhwcolor);
set(H_pa02,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
H_pa03 = patch([datenum(2022,8,23),datenum(2022,8,23),datenum(2022,9,4),datenum(2022,9,4)],...
    [-120,120,120,-120],mhwcolor);
set(H_pa03,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
%
H_pa1 = patch([datenum(2022,7,8),datenum(2022,7,8),datenum(2022,7,15),datenum(2022,7,15)],...
    [-50,100,100,-50],cohwcolor);
set(H_pa1,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
H_pa2 = patch([datenum(2022,8,2),datenum(2022,8,2),datenum(2022,8,23),datenum(2022,8,23)],...
    [-50,100,100,-50],cohwcolor);
set(H_pa2,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
hold on
yyaxis right
plot(xx,mld_2022,'color',[0, 0.6, 1],'LineWidth',3)
% plot(xx,mld_ano2022,'color',[0.6, 0.8, 1],'LineWidth',2)
hold on 
x0=zeros(size(xx,2),1);
plot(xx,x0,'k-.');
hold on
ylabel('MLD (m)','fontsize',20,'FontName','Arial');
ylim([6 24])
yticks([6:6:24])
xlim([datenum(2022,6,20) datenum(2022,9,10)]);
set(gca,'fontsize',24,'FontName','Arial');
set(gca,'linewidth',2)
grid off
box on
% 500hPa gpm
hold on
yyaxis left
hh=bar(xx,m_z500_ano_JJAS)
set(hh,'FaceColor',[70/256 10/256 119/256],'EdgeColor','none')
hold on
xlim([datenum(2022,6,20) datenum(2022,9,10)]);
xticks([datenum(2022,6,30) datenum(2022,7,31) datenum(2022,8,31)]);
datetick('x','mm/dd','keeplimits','keepticks');
yticks([-40:40:80])
ylim([-40 80])
ylabel('Z500 (gpm)','fontsize',20,'FontName','Arial');

%% Qnet & SSR
subplot(211)
xx=[datenum(2022,6,1):datenum(2022,9,30)];
xd1=datenum(2022,7,15)-datenum(2022,7,8)+1;
xd2=datenum(2022,8,23)-datenum(2022,8,4)+1;
%
H_pa01 = patch([datenum(2022,6,30),datenum(2022,6,30),datenum(2022,7,8),datenum(2022,7,8)],...
    shadehigh,mhwcolor);
set(H_pa01,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
H_pa02 = patch([datenum(2022,7,15),datenum(2022,7,15),datenum(2022,8,2),datenum(2022,8,2)],...
    shadehigh,mhwcolor);
set(H_pa02,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
H_pa03 = patch([datenum(2022,8,23),datenum(2022,8,23),datenum(2022,9,4),datenum(2022,9,4)],...
    shadehigh,mhwcolor);
set(H_pa03,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
%
H_pa1 = patch([datenum(2022,7,8),datenum(2022,7,8),datenum(2022,7,15),datenum(2022,7,15)],...
    shadehigh,cohwcolor);
set(H_pa1,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
hold on
H_pa2 = patch([datenum(2022,8,2),datenum(2022,8,2),datenum(2022,8,23),datenum(2022,8,23)],...
    shadehigh,cohwcolor);
set(H_pa2,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
hold on
plot([datenum(2022,6,1) datenum(2022,9,30)],[0 0],'k--');
hold on
% % % yyaxis left
hh1=bar(xx,m_ssr_ano_JJAS)%pink
set(hh1,'FaceColor',[250/256 0 126/256],'EdgeColor','none')
legend(hh1,'Shortwave radiation','location','best','fontsize',14);
hold on
c=plot(xx,Q_ano_JJAS,'color','k','LineWidth',2)
legend(c,'Surface net heat flux','location','best','fontsize',12);
% ylabel('W/m^2','fontsize',20);
ylim([-140 140]);
xlim([datenum(2022,6,20) datenum(2022,9,10)]);
yticks([-140:70:140]);
xticks([datenum(2022,6,30) datenum(2022,7,31) datenum(2022,8,31)]);
datetick('x','mm/dd','keeplimits','keepticks');
grid off
set(gca,'linewidth',2)
set(gca,'fontsize',24,'FontName','Arial');
ylabel('W/m^2','fontsize',20);
box on
