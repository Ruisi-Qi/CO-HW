clc
clear all
close all
load Figure_1a.mat XI YI t2mano82_23 WhiteBlueGreenYellowRed sst_interp

figure(1)
set(gcf,'unit','centimeters','position',[1,2,20,15])
m_proj('Equidistant Cylindrical','lon',[112 130],'lat',[26 36]);

h1= m_contourf(XI,YI,t2mano82_23',[0:0.1:20],'linestyle','none');
shading flat
hold on
set(gca,'FontSize',24);
set(gca,'linewidth',2,'fontangle','oblique')

colormap(WhiteBlueGreenYellowRed)
set(gca,'FontSize',24);
set(gca,'linewidth',1.5,'fontangle','oblique')
m_coast('color','k','linewidth',2)
hbar1=colorbar('vertical');
set(hbar1,'fontsize',24,'fontname','Arial','fontangle','oblique','linewidth',2)
caxis([-1 6]);
hbar1.Label.String='T2m (\circC)';
hbar1.Label.FontSize=24;
hold on
set(gca,'FontSize',24);
set(gca,'linewidth',2,'fontangle','oblique')
linecolor1=[0.78,0.04,0.4];
tickcolor1=[0.78,0.04,0.4];
hold on
[C h]=m_contour(XI,YI,sst_interp',[1 1],'linewidth',1.6,'color',linecolor1);
clabel(C,h,'FontSize',12, 'color',tickcolor1);
hold on
[C h]=m_contour(XI,YI,sst_interp',[1.5 1.5],'linewidth',2,'color',linecolor1);
clabel(C,h,'FontSize',12, 'color',tickcolor1);
hold on
[C h]=m_contour(XI,YI,sst_interp',[2 2],'linewidth',2.4,'color',linecolor1);
clabel(C,h,'FontSize',12, 'color',tickcolor1);
hold on
[C h]=m_contour(XI,YI,sst_interp',[2.5 2.5],'linewidth',2.8,'color',linecolor1);
clabel(C,h,'FontSize',12, 'color',tickcolor1);
hold on
[C h]=m_contour(XI,YI,sst_interp',[3 3],'linewidth',3.2,'color',linecolor1);
clabel(C,h,'FontSize',12, 'color',tickcolor1);
hold on
[C h]=m_contour(XI,YI,sst_interp',[3.5 3.5],'linewidth',3.6,'color',linecolor1);
clabel(C,h,'FontSize',12, 'color',tickcolor1);
hold on
set(gca,'FontSize',12);
set(gca,'linewidth',1.5,'fontangle','oblique')

m_grid('linestyle','none','xaxisloc','bottom','yaxisloc','left','fontsize',24,...
'xtick',[112:6:130],'Xticklabel',[112:6:130],...
'ytick',[26:2:36],'Yticklabel',[26:2:36],'box','on','fontname','Arial');

set(gca,'FontSize',24);
set(gca,'linewidth',2,'fontangle','oblique')
box on
hold on
m_box(115,128,27,35,[0.38,0.36,0.36],3)
