
clc
clear all
close all
load('Figure_5a.mat')
m_proj('Equidistant Cylindrical','lon',[90 130],'lat',[20 40]);
m_contourf(X,Y,z500ano_combine',[-1500:1:1500],'linestyle','none');
set(gca,'FontSize',24);
set(gca,'linewidth',2);
hold on
shading flat
colormap(mycmap)
hold on
caxis([-1500 1500]);
hold on
%dot
hold on
clear a aa
aa=abs(z500ano_combine)-z500_combine_stderror;% z500_combine anomaly standard error
a=find(aa'>0);
m_plot(X(a),Y(a),'.','MarkerEdgeColor','k','MarkerSize',1.5);
hold on
%
m_box(115,128,27,35,'k',1.5)
hold on
m_contour(X,Y,z500_combine',[5880 5880],'LineColor',[6/255,192/255,95/255],'linewidth',2);
hold on
m_grid('linestyle','none','xaxisloc','bottom','yaxisloc','left','fontsize',24,...
'xtick',[90:10:130],'Xticklabel',[90:10:130],...
'ytick',[20:5:40],'Yticklabel',[20:5:40],'box','on','fontname','Arial');
m_coast('linewidth',2,'color','k');
set(gca,'FontSize',24);
set(gca,'linewidth',2)
box on
c=colorbar('vertical','fontname','Arial');
set(c,'fontsize',20,'linewidth',2)%%%

