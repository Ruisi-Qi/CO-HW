



clc
clear all
close all
load Figure_3a_3b.mat
%%  July
figure(1)
subplot(2,1,1)
m_proj('Equidistant Cylindrical','lon',[0,180],'lat',[10,60]);
m_proj('Equidistant Cylindrical','lon',[0,180],'lat',[10,60]);
m_contourf(X,Y,ghano202207',[-150:10:150],'linestyle','none');
hold on
colormap(mycmap)
caxis([-120 120]);
hold on
shading flat
m_coast('linewidth',1,'color','k');
set(gca,'linewidth',2)
%
hold on
[C h]=m_contour(X,Y,gh202207','linewidth',4,'color',[0.34,0.40,0.35]);
clabel(C,h,'FontSize',12, 'color','k','LabelSpacing', 10000,'FontWeight', 'bold');
% wind
hold on
d=1;
dd=1;
q=m_quiver(X1(1:d:end,1:d:end),Y1(1:d:end,1:d:end),uw_202207(1:d:end,1:d:end).*dd,vw_202207(1:d:end,1:d:end).*dd,0,'Linewidth',1.25,'color','k','MaxHeadSize',0.05)
hold on
bnd_lon=180;
bnd_lat=10;
xx=[bnd_lon-10 bnd_lon bnd_lon bnd_lon-10];
yy=[bnd_lat bnd_lat bnd_lat+6 bnd_lat+6];
m_patch(xx,yy,'w','LineWidth',1.5); hold on;
z=4;
m_text(bnd_lon-8.8,bnd_lat+4,[num2str(z) 'm/s'],'fontname','Arial','fontsize',16)
hold on
h=m_quiver(bnd_lon-7.5,bnd_lat+2,z.*dd,0,0);
set(h,'color','k','LineWidth',1,'MaxHeadSize',1);
hold on
set(q,'color','k','LineWidth',1.25);
% wind
m_grid('linestyle','none','box','on','tirkdir','in','fontname','Arial',...
'fontsize',24,'xtick',0:30:180,'xticklabel',[]);
set(gca,'FontSize',24);
set(gca,'linewidth',2)
hold on
m_box(115,128,27,35,'k',2)
box on
%%  August
figure(2)
subplot(2,1,1)
m_proj('Equidistant Cylindrical','lon',[0,180],'lat',[10,60]);
m_proj('Equidistant Cylindrical','lon',[0,180],'lat',[10,60]);
m_contourf(X,Y,ghano202208',[-150:10:150],'linestyle','none');
hold on
colormap(mycmap)
caxis([-120 120]);
hold on
shading flat
m_coast('linewidth',1,'color','k');
set(gca,'linewidth',2)
%
hold on
[C h]=m_contour(X,Y,gh202208','linewidth',4,'color',[0.34,0.40,0.35]);
clabel(C,h,'FontSize',12, 'color','k','LabelSpacing', 1000,'FontWeight', 'bold');
% wind
hold on
d=1;
dd=1;
q=m_quiver(X1(1:d:end,1:d:end),Y1(1:d:end,1:d:end),uw_202208(1:d:end,1:d:end).*dd,vw_202208(1:d:end,1:d:end).*dd,0,'Linewidth',1.25,'color','k','MaxHeadSize',0.05)
hold on
bnd_lon=180;
bnd_lat=10;
xx=[bnd_lon-10 bnd_lon bnd_lon bnd_lon-10];
yy=[bnd_lat bnd_lat bnd_lat+6 bnd_lat+6];
m_patch(xx,yy,'w','LineWidth',1.5); hold on;
z=4;
m_text(bnd_lon-8.8,bnd_lat+4,[num2str(z) 'm/s'],'fontname','Arial','fontsize',16)
hold on
h=m_quiver(bnd_lon-7.5,bnd_lat+2,z.*dd,0,0);
set(h,'color','k','LineWidth',1,'MaxHeadSize',1);
hold on
set(q,'color','k','LineWidth',1.25);
% wind
m_grid('linestyle','none','box','on','tirkdir','in','fontname','Arial',...
'fontsize',24,'xtick',0:30:180,'xticklabel',0:30:180);
set(gca,'FontSize',24);
set(gca,'linewidth',2)
hold on
m_box(115,128,27,35,'k',2)
box on
c=colorbar('horizontal','position',[0.28 0.52 0.48 0.015],'fontname','Arial');
set(c,'fontsize',20,'linewidth',2);
c.Label.String='gpm';
c.Label.Rotation=0;
c.Label.FontSize=20;