clear all
close all
clc
load Figure_3c_3d.mat
%%
figure(1)
subplot(2,1,1)
clim=squeeze(mclim(:,:,7));
m_proj('Equidistant Cylindrical','lon',[60,180],'lat',[10,60]);
m_contourf(X,Y,ghano202207',[-120:5:120],'linestyle','none');
hold on
caxis([-65 65]);
shading flat
m_coast('linewidth',1,'color','k');
set(gca,'linewidth',2)
% 
hold on
m_contour(X,Y,gh202207',[5880 5880],'LineColor',[6/255,192/255,95/255],'linewidth',5);
hold on
m_contour(X,Y,clim',[5880 5880],'LineColor',[255/255,102/255,204/255],'linewidth',5,'linestyle','--');
%
hold on
colormap(mycmap)
% wind
d=1;
dd=1;
q=m_quiver(X1(1:d:end,1:d:end),Y1(1:d:end,1:d:end),uw_202207(1:d:end,1:d:end).*dd,vw_202207(1:d:end,1:d:end).*dd,0,'Linewidth',1.25,'color','k','MaxHeadSize',0.05)
hold on
bnd_lon=180;%
bnd_lat=10;
xx=[bnd_lon-10 bnd_lon bnd_lon bnd_lon-10];%
yy=[bnd_lat bnd_lat bnd_lat+6 bnd_lat+6];
m_patch(xx,yy,'w','LineWidth',1.5); hold on;
z=4;% 
m_text(bnd_lon-8.5,bnd_lat+4,[num2str(z) 'm/s'],'fontname','Arial','fontsize',16)
hold on
h=m_quiver(bnd_lon-7.5,bnd_lat+2,z.*dd,0,0);
set(h,'color','k','LineWidth',1,'MaxHeadSize',1);
hold on
set(q,'color','k','LineWidth',1.25);
m_grid('linestyle','none','box','on','tirkdir','in','fontname','Arial',...
'fontsize',24,'xtick',60:30:180,'xticklabel',[]);
set(gca,'FontSize',24);
set(gca,'linewidth',2)
box on
hold on
m_box(115,128,27,35,'k',2)
%%  August
figure(2)
subplot(2,1,1)
clim=squeeze(mclim(:,:,8));
m_proj('Equidistant Cylindrical','lon',[60,180],'lat',[10,60]);
m_contourf(X,Y,ghano202208',[-120:5:120],'linestyle','none');
hold on
caxis([-65 65]);
shading flat
m_coast('linewidth',1,'color','k');
set(gca,'linewidth',2)
hold on
m_contour(X,Y,gh202208',[5880 5880],'LineColor',[6/255,192/255,95/255],'linewidth',5);
hold on
m_contour(X,Y,clim',[5880 5880],'LineColor',[255/255,102/255,204/255],'linewidth',5,'linestyle','--');
%
hold on
colormap(mycmap)
% wind
d=1;
dd=1;
q=m_quiver(X1(1:d:end,1:d:end),Y1(1:d:end,1:d:end),uw_202208(1:d:end,1:d:end).*dd,vw_202208(1:d:end,1:d:end).*dd,0,'Linewidth',1.25,'color','k','MaxHeadSize',0.05)
hold on
bnd_lon=180;
bnd_lat=10;
xx=[bnd_lon-10 bnd_lon bnd_lon bnd_lon-10];
yy=[bnd_lat bnd_lat bnd_lat+6 bnd_lat+6];
m_patch(xx,yy,'w','LineWidth',1.5); hold on;
z=4;% 
m_text(bnd_lon-8.5,bnd_lat+4,[num2str(z) 'm/s'],'fontname','Arial','fontsize',16)
hold on
h=m_quiver(bnd_lon-7.5,bnd_lat+2,z.*dd,0,0);
set(h,'color','k','LineWidth',1,'MaxHeadSize',1);
hold on
set(q,'color','k','LineWidth',1.25);
m_grid('linestyle','none','box','on','tirkdir','in','fontname','Arial',...
'fontsize',24,'xtick',60:30:180,'xticklabel',60:30:180);
set(gca,'FontSize',24);
set(gca,'linewidth',2)
box on
set(gca,'linewidth',2)
box on
hold on
m_box(115,128,27,35,'k',2)
c=colorbar('horizontal','position',[0.355 0.52 0.32 0.015],'fontname','Arial');
set(c,'fontsize',20,'linewidth',2)%%%
c.Label.String='gpm';
c.Label.Rotation=0;
c.Label.FontSize=20;

