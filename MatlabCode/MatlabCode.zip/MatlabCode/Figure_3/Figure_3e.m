% print 2022 co-hw 时期的v-wind
clear all
close all
clc
load Figure_2e.mat
%% cohw-1 2022 1st CO-HW
% figure(1)
% 
% m_proj('Equidistant Cylindrical','lon',[-120,180],'lat',[-10,60]);
% m_contourf(X,Y, qq_m_vwind_ano_cohw1,[-100:1:100],'linestyle','none');
% hold on
% set(gca,'FontSize',18);
% set(gca,'linewidth',2)
% colormap(mycmap)
% shading flat
% m_grid('linestyle','none','box','on','tirkdir','in','fontname','Arial',...
% 'fontsize',18);
% m_coast('linewidth',1,'color','k');
% set(gca,'FontSize',18);
% set(gca,'linewidth',2)
% caxis([-12 12]);
% c=colorbar
% c.Label.String='m/s';
% grid off
% box on

%% cohw-2 2022 2nd CO-HW
figure(2)
m_proj('Equidistant Cylindrical','lon',[-120,180],'lat',[-10,60]);
m_contourf(X,Y, qq_m_vwind_ano_cohw2,[-20:1:20],'linestyle','none');
hold on
set(gca,'FontSize',18);
set(gca,'linewidth',2)
colormap(mycmap)
shading flat
m_grid('linestyle','none','box','on','tirkdir','in','fontname','Arial',...
'fontsize',18);
m_coast('linewidth',1,'color','k');
set(gca,'FontSize',18);
set(gca,'linewidth',2)
box on
caxis([-8 8]);
c=colorbar
c.Label.String='m/s';
grid off
box on