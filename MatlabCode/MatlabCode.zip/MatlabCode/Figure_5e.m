clear all
clc
close all
load Figure_5e.mat
%%
[r22 p22]=corr_s(m_ssr_ano_annual,m_qnet_ano_annual,0.99)
coday=year_JA(2,:);
coday(coday==0)=[];
sz=coday.*40;
ye=year_JA(1,:);
ye(year_JA(2,:)==0)=[];
figure(1)
set(gcf,'unit','centimeters','position',[1,2,30,25])
for i=1:14
    scatter(m_ssr_ano_annual(i),m_qnet_ano_annual(i),sz(i), filledcolor(i,:),'filled');
    hold on
end
xlabel('Shortwave Radiation (W/m^2)','FontSize',24)
ylabel('Surface net heat flux (W/m^2)','FontSize',24)
ylim([-100 400])
xlim([0 900])
colormap(red_5colormat)
c = colorbar('Ticks',[0:0.2:1],...
         'TickLabels',[0:0.2:1])
c.LineWidth = 2;
set(gca,'FontSize',18,'lineWidth',2);
hold on
box on

for i=1:length(ye)
    if i==14
        hold on
        text(m_ssr_ano_annual(i)-60,m_qnet_ano_annual(i),num2str(ye(i)),'FontSize',18,'fontname','Arial','Color','r');
    else
        hold on
        text(m_ssr_ano_annual(i)-60,m_qnet_ano_annual(i),num2str(ye(i)),'FontSize',18,'fontname','Arial');
    end
    
end
set(gca,'tickdir','out')
box on
set(gca,'linewidth',3,'fontname','Arial')

