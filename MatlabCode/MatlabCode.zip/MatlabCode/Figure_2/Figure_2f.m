%% budget ocean mld-temp no We
%% PRINT
clc
clear alll
close all

load Figure_2f.mat

figure(1)
hh=[datenum(1993,1,1):datenum(2022,12,31)];
xd1=datenum(2022,7,15)-datenum(2022,7,8)+1;
xd2=datenum(2022,8,23)-datenum(2022,8,2)+1;
cohwcolor=[169/256 56/256 51/256];
mhwcolor=[1 0.5 0.5];
shadehigh=[-160,160,160,-160];
%  subplot(212)
xx=[datenum(2022,6,1):datenum(2022,9,30)];
%
H_pa01 = patch([datenum(2022,6,30),datenum(2022,6,30),datenum(2022,7,8),datenum(2022,7,8)],...
    [-120,120,120,-120],mhwcolor);
set(H_pa01,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
H_pa02 = patch([datenum(2022,7,15),datenum(2022,7,15),datenum(2022,8,2),datenum(2022,8,2)],...
    [-120,120,120,-120],mhwcolor);
set(H_pa02,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
H_pa03 = patch([datenum(2022,8,23),datenum(2022,8,23),datenum(2022,9,4),datenum(2022,9,4)],...
    [-120,120,120,-120],mhwcolor);
set(H_pa03,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
%
H_pa1 = patch([datenum(2022,7,8),datenum(2022,7,8),datenum(2022,7,15),datenum(2022,7,15)],...
    [-50,100,100,-50],cohwcolor);
set(H_pa1,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
H_pa2 = patch([datenum(2022,8,2),datenum(2022,8,2),datenum(2022,8,23),datenum(2022,8,23)],...
    [-50,100,100,-50],cohwcolor);
set(H_pa2,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
hold on
plot(hh,R_ano_sm,'color',[237 125 49]/255,'linestyle','-','linewi',3)%brown
hold on
plot(hh,m_Tt_ano_sm,'color','k','linestyle','-','linewi',3.5)%black
hold on
plot(hh,m_Q_ano_sm,'color',[245 35 137]/255,'linestyle','-','linewi',3)%pink
hold on
plot(hh,m_adv_ano_sm,'color',[49 199 209]/255,'linestyle','-','linewi',3)%blue
hold on
% 
x0=zeros(size(hh,2),1);
plot(hh,x0,'k-.','LineWidth',2);
xlim([datenum(2022,6,20) datenum(2022,9,10)]);
xticks([datenum(2022,6,30) datenum(2022,7,31) datenum(2022,8,31)]);
datetick('x','mm/dd','keeplimits','keepticks');
yticks([-0.3:0.1:0.2])
ylim([-0.3 0.2])
set(gca,'fontsize',24,'FontName','Arial');
set(gca,'linewidth',2)
grid off
box on
ylabel('\circC/day','fontsize',24,'fontname','Arial')
