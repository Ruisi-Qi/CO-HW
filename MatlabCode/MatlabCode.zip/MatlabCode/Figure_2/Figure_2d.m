clc
close all
clear all

%% Qnet-atmosphere
load Figure_2d.mat
xx=[datenum(2022,6,1):datenum(2022,9,30)];
xd1=datenum(2022,7,15)-datenum(2022,7,8)+1;
xd2=datenum(2022,8,23)-datenum(2022,8,2)+1;
cohwcolor=[169/256 56/256 51/256];
mhwcolor=[1 0.5 0.5];
shading_high=[-280,280,280,-280];
%% ssr sshf slhf str ano
H_pa01 = patch([datenum(2022,6,30),datenum(2022,6,30),datenum(2022,7,8),datenum(2022,7,8)],...
   shading_high,mhwcolor);
set(H_pa01,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
H_pa02 = patch([datenum(2022,7,15),datenum(2022,7,15),datenum(2022,8,2),datenum(2022,8,2)],...
    shading_high,mhwcolor);
set(H_pa02,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
H_pa03 = patch([datenum(2022,8,23),datenum(2022,8,23),datenum(2022,9,4),datenum(2022,9,4)],...
    shading_high,mhwcolor);
set(H_pa03,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
%
H_pa1 = patch([datenum(2022,7,8),datenum(2022,7,8),datenum(2022,7,15),datenum(2022,7,15)],...
    shading_high,cohwcolor);
set(H_pa1,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
H_pa2 = patch([datenum(2022,8,2),datenum(2022,8,2),datenum(2022,8,23),datenum(2022,8,23)],...
    shading_high,cohwcolor);
set(H_pa2,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
hold on

c1=bar(xx,Q_ano_JJAS_a)
set(c1,'FaceColor','k','EdgeColor','none','FaceAlpha',0.5)% ? bar的透明度
hold on
plot(xx,m_ssr_ano_JJAS_a,'color',[250/256 0 126/256],'LineWidth',3)%pink
hold on
plot(xx,m_str_ano_JJAS_a,'color',[34/256 137/256 241/256],'LineWidth',3)%blue
hold on
plot(xx,m_sshf_ano_JJAS_a,'color',[0/256 204/256 102/256],'LineWidth',3)%% green
hold on
plot(xx,m_slhf_ano_JJAS_a,'color',[251/256 128/256 26/256],'LineWidth',3)% orange
hold on
ylabel('W/m^2','fontsize',24);
xlim([datenum(2022,6,20) datenum(2022,9,10)]);
ylim([-100 100]);
yticks([-100:50:100]);
xticks([datenum(2022,6,30) datenum(2022,7,31) datenum(2022,8,31)]);
datetick('x','mm/dd','keeplimits','keepticks');
hold on
set(gca,'linewidth',2)
set(gca,'fontsize',24,'FontName','Arial');
box on

