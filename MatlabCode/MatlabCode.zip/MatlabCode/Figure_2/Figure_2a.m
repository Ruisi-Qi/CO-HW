clc
close all
clear all

load Figure_2a.mat

xx=[datenum(2022,6,1):datenum(2022,9,30)];
xd1=datenum(2022,7,15)-datenum(2022,7,8)+1;
xd2=datenum(2022,8,23)-datenum(2022,8,2)+1;
cohwcolor=[169/256 56/256 51/256];
mhwcolor=[1 0.5 0.5];
shadehigh=[-160,160,160,-160];

%% 500hPa & mld thickness 

figure(1)
xx=[datenum(2022,6,1):datenum(2022,9,30)];
%
H_pa01 = patch([datenum(2022,6,30),datenum(2022,6,30),datenum(2022,7,8),datenum(2022,7,8)],...
    [-120,120,120,-120],mhwcolor);
set(H_pa01,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
H_pa02 = patch([datenum(2022,7,15),datenum(2022,7,15),datenum(2022,8,2),datenum(2022,8,2)],...
    [-120,120,120,-120],mhwcolor);
set(H_pa02,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
H_pa03 = patch([datenum(2022,8,23),datenum(2022,8,23),datenum(2022,9,4),datenum(2022,9,4)],...
    [-120,120,120,-120],mhwcolor);
set(H_pa03,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
%
H_pa1 = patch([datenum(2022,7,8),datenum(2022,7,8),datenum(2022,7,15),datenum(2022,7,15)],...
    [-50,100,100,-50],cohwcolor);
set(H_pa1,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
H_pa2 = patch([datenum(2022,8,2),datenum(2022,8,2),datenum(2022,8,23),datenum(2022,8,23)],...
    [-50,100,100,-50],cohwcolor);
set(H_pa2,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
hold on
yyaxis right
plot(xx,mld_2022,'color',[0, 0.6, 1],'LineWidth',3);
hold on 
x0=zeros(size(xx,2),1);
plot(xx,x0,'k-.');
hold on
ylabel('MLD (m)','fontsize',20,'FontName','Arial');
ylim([6 24])
yticks([6:6:24])
xlim([datenum(2022,6,20) datenum(2022,9,10)]);
set(gca,'fontsize',24,'FontName','Arial');
set(gca,'linewidth',2)
grid off
box on
% 500hPa gpm
hold on
hold on
yyaxis left
hh=bar(xx,m_z500_ano_JJAS)
set(hh,'FaceColor',[70/256 10/256 119/256],'EdgeColor','none');
hold on 
xlim([datenum(2022,6,20) datenum(2022,9,10)]);
xticks([datenum(2022,6,30) datenum(2022,7,31) datenum(2022,8,31)]);
datetick('x','mm/dd','keeplimits','keepticks');
yticks([-40:40:80])
ylim([-40 80])
ylabel('Z500 (gpm)','fontsize',20,'FontName','Arial');


