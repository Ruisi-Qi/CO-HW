%% low cover letter ano

clear all
clc
close all
load Figure_2b.mat 

figure(1)
subplot(121)
m_proj('Equidistant Cylindrical','lon',[90 130],'lat',[20 40]);
m_contourf(X,Y,average_cohw_2022',[-100:1:100],'linestyle','none');
hold on
shading flat
set(gca,'FontSize',24);
set(gca,'linewidth',2);
colormap(mycmap)
hold on
caxis([-30 30]);
hold on
m_grid('linestyle','none','xaxisloc','bottom','yaxisloc','left','fontsize',24,...
'xtick',[90:10:130],'Xticklabel',[],...
'ytick',[20:5:40],'Yticklabel',[20:5:40],'box','on','fontname','Arial');
m_coast('linewidth',2,'color','k');
hold on
m_box(115,128,27,35,'k',2)
c=colorbar('horizontal','fontname','Arial');
set(c,'fontsize',20,'linewidth',2)%%%
c.Label.String='%';