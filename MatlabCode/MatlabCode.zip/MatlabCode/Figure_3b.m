close all
clear all
clc
load Figure_3b.mat
m_proj('Equidistant Cylindrical','lon',[90 130],'lat',[20 40]);
m_contourf(X,Y,Qnet_ano_annual_2022',[-3200:1:3200],'linestyle','none');
set(gca,'FontSize',24);
set(gca,'linewidth',2);
colormap(gca,mycmap)
hold on
shading flat
m_grid('linestyle','none','xaxisloc','bottom','yaxisloc','left','fontsize',24,...
'xtick',[90:10:130],'Xticklabel',[90:10:130],...
'ytick',[20:5:40],'Yticklabel',[20:5:40],'box','on','fontname','Arial');
m_coast('linewidth',2,'color','k');
caxis([-1500 1500]);
c=colorbar('vertical','fontname','Arial');
set(c,'fontsize',20,'linewidth',2)%%%
hold on
m_box(115,128,27,35,'k',1.5)
set(gca,'FontSize',24);
set(gca,'linewidth',2)
box on
