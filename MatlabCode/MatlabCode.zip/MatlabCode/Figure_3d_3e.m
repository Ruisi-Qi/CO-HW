clc
close all
clear all
load Figure_3d_3e.mat

subplot(311)
xx=[datenum(2022,6,1):datenum(2022,9,30)];
xd1=datenum(2022,7,15)-datenum(2022,7,8)+1;
xd2=datenum(2022,8,23)-datenum(2022,8,2)+1;
%
H_pa01 = patch([datenum(2022,6,30),datenum(2022,6,30),datenum(2022,7,8),datenum(2022,7,8)],...
    [-120,120,120,-120],mhwcolor);
set(H_pa01,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
H_pa02 = patch([datenum(2022,7,15),datenum(2022,7,15),datenum(2022,8,2),datenum(2022,8,2)],...
    [-120,120,120,-120],mhwcolor);
set(H_pa02,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
H_pa03 = patch([datenum(2022,8,23),datenum(2022,8,23),datenum(2022,9,4),datenum(2022,9,4)],...
    [-120,120,120,-120],mhwcolor);
set(H_pa03,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
%
H_pa1 = patch([datenum(2022,7,8),datenum(2022,7,8),datenum(2022,7,15),datenum(2022,7,15)],...
    [-50,100,100,-50],cohwcolor);
set(H_pa1,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
H_pa2 = patch([datenum(2022,8,2),datenum(2022,8,2),datenum(2022,8,23),datenum(2022,8,23)],...
    [-50,100,100,-50],cohwcolor);
set(H_pa2,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
hold on
plot([datenum(2022,6,1) datenum(2022,9,30)],[0 0],'k--');
hold on
% 500hPa gpm
hold on
m_z500_ano_JJAS=squeeze(m_z500_ano(datenum(2022,6,1)-datenum(1982,1,1)+1:datenum(2022,9,30)-datenum(1982,1,1)+1));
hh=plot(xx,m_z500_ano_JJAS,'color',[70/256 10/256 119/256],'LineWidth',2)
hold on
xlim([datenum(2022,6,1) datenum(2022,9,30)]);
xticks([datenum(2022,6,1) datenum(2022,6,30) datenum(2022,7,31) datenum(2022,8,31) datenum(2022,9,30)]);
datetick('x','mm/dd','keeplimits','keepticks');
yticks([-50:25:100])
ylim([-50 100])
ylabel('gpm','fontsize',14,'FontName','Arial');
set(gca,'fontsize',14,'FontName','Arial','fontangle','oblique');
set(gca,'linewidth',2)
grid off
box on
Q=squeeze(m_sshf_ano+m_str_ano+m_slhf_ano+m_ssr_ano);
Q_ano_JJAS=Q(datenum(2022,6,1)-datenum(1982,1,1)+1:datenum(2022,9,30)-datenum(1982,1,1)+1);
% 
subplot(312)
xx=[datenum(2022,6,1):datenum(2022,9,30)];
xd1=datenum(2022,7,15)-datenum(2022,7,8)+1;
xd2=datenum(2022,8,23)-datenum(2022,8,4)+1;
%
H_pa01 = patch([datenum(2022,6,28),datenum(2022,6,28),datenum(2022,7,8),datenum(2022,7,8)],...
    shadehigh,mhwcolor);
set(H_pa01,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)

hold on
H_pa02 = patch([datenum(2022,7,15),datenum(2022,7,15),datenum(2022,8,2),datenum(2022,8,2)],...
    shadehigh,mhwcolor);
set(H_pa02,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)

hold on
H_pa03 = patch([datenum(2022,8,23),datenum(2022,8,23),datenum(2022,9,4),datenum(2022,9,4)],...
    shadehigh,mhwcolor);
set(H_pa03,'EdgeColor','none','EdgeAlpha',0.5,'FaceAlpha',0.15)
hold on
%
H_pa1 = patch([datenum(2022,7,8),datenum(2022,7,8),datenum(2022,7,15),datenum(2022,7,15)],...
    shadehigh,cohwcolor);
set(H_pa1,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
hold on
H_pa2 = patch([datenum(2022,8,2),datenum(2022,8,2),datenum(2022,8,23),datenum(2022,8,23)],...
    shadehigh,cohwcolor);
set(H_pa2,'EdgeColor','none','EdgeAlpha',1,'FaceAlpha',0.3,'LineWidth',3)
hold on
plot([datenum(2022,6,1) datenum(2022,9,30)],[0 0],'k--');
hold on
m_ssr_ano_JJAS=squeeze(m_ssr_ano(datenum(2022,6,1)-datenum(1982,1,1)+1:datenum(2022,9,30)-datenum(1982,1,1)+1));
hh1=bar(xx,m_ssr_ano_JJAS)
set(hh1,'FaceColor',[250/256 0 126/256],'EdgeColor','none')
hold on
c=plot(xx,Q_ano_JJAS,'color','k','LineWidth',2)
c.Color(4)=0.7
ylabel('W/m^2','fontsize',14);
xlim([datenum(2022,6,1) datenum(2022,9,30)]);
ylim([-140 140]);
yticks([-140:70:140]);
xticks([datenum(2022,6,1) datenum(2022,6,30) datenum(2022,7,31) datenum(2022,8,31) datenum(2022,9,30)]);
datetick('x','mm/dd','keeplimits','keepticks');
grid off
hold on
set(gca,'linewidth',2)
set(gca,'fontsize',14,'FontName','Arial','fontangle','oblique');
box on
