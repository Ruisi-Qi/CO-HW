
clc
clear all
close all

%% z500
load Figure_5a.mat 
figure(1)
subplot(121)
m_proj('Equidistant Cylindrical','lon',[90 130],'lat',[20 40]);
m_contourf(X,Y,z500ano_combine',[-500:1:500],'linestyle','none');
set(gca,'FontSize',24);
set(gca,'linewidth',2);
hold on
shading flat
colormap(mycmap)
hold on
caxis([-300 300]);
hold on
%dot
hold on
clear a aa
aa=abs(z500ano_combine)-z500_combine_stderror;
clear aa_int
lonq1=[lonr(1):2:lonr(end)];
latq1=[latr(1):2:latr(end)];
[XX1,YY1]=meshgrid(lonq1,latq1);
aa_int=interp2(X,Y,aa',XX1,YY1);
a=find(aa_int>0);
m_plot(XX1(a),YY1(a),'.','MarkerEdgeColor','k','MarkerSize',8);
hold on
%dot
m_box(115,128,27,35,'k',2)
hold on
m_contour(X,Y,z500_combine',[5880 5880],'LineColor',[0.72 0.27 1],'linewidth',2);
m_grid('linestyle','none','xaxisloc','bottom','yaxisloc','left','fontsize',24,...
'xtick',[90:10:130],'Xticklabel',[90:10:130],...
'ytick',[20:5:40],'Yticklabel',[20:5:40],'box','on','fontname','Arial');
m_coast('linewidth',2,'color','k');
set(gca,'FontSize',24);
set(gca,'linewidth',2)
box on
% c=colorbar('vertical','fontname','Arial');
% set(c,'fontsize',20,'linewidth',2)%%%
% c.Label.String='gpm';
% c.Label.Rotation=0;
% c.Label.FontSize=16;

