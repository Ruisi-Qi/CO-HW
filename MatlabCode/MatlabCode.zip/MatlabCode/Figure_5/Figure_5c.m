
clc
clear all
close all
load Figure_5c.mat
%% print SSR 
[X,Y]=meshgrid(lonr,latr);
figure(1)
subplot(121)
m_proj('Equidistant Cylindrical','lon',[90 130],'lat',[20 40]);
m_contourf(X,Y,ssr_combine',[-1500:1:1500],'linestyle','none');
set(gca,'FontSize',24);
set(gca,'linewidth',2);
colormap(mycmap)
hold on
shading flat
m_grid('linestyle','none','xaxisloc','bottom','yaxisloc','left','fontsize',24,...
'xtick',[90:10:130],'Xticklabel',[90:10:130],...
'ytick',[20:5:40],'Yticklabel',[],'box','on','fontname','Arial');
m_coast('linewidth',2,'color','k');
caxis([-1500 1500]);
%dot
hold on
clear a aa
aa=abs(ssr_combine)-ssr_combine_stderror;
%
clear aa_int
lonq1=[lonr(1):2:lonr(end)];
latq1=[latr(1):2:latr(end)];
[XX1,YY1]=meshgrid(lonq1,latq1);
aa_int=interp2(X,Y,aa',XX1,YY1);
%
a=find(aa_int>0);
m_plot(XX1(a),YY1(a),'.','MarkerEdgeColor','k','MarkerSize',8);
%dot
hold on
m_box(115,128,27,35,'k',2)
set(gca,'FontSize',24);
set(gca,'linewidth',2)
box on
