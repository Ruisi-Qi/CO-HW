clear all
close all
clc
load Figure_4d.mat
%%
figure(1)
[r22 p22]=corr_s(westindex_annualmean,m_z500_ano_annual,0.95)
coday=year_JA(2,:);
coday(coday==0)=[];
sz=coday.*100;
ye=year_JA(1,:);
ye(year_JA(2,:)==0)=[];
% figure(1)
set(gcf,'unit','centimeters','position',[1,2,30,25])
for i=1:14
    scatter(westindex_annualmean(i),m_z500_ano_annual(i),sz(i), filledcolor(i,:),'filled');
    hold on
end
xlabel('WPSH west extension index (W/m^2)','FontSize',26)
ylabel('Z500 (gpm)','FontSize',26)
xlim([90 130])
str=get(gca,'xticklabel');
strtxt=strcat(str,'°E');
set(gca,'xticklabel',strtxt);
colormap(red_5colormat)%%少这个！！！！
c = colorbar('Ticks',[0:0.2:1],...
         'TickLabels',[0:0.2:1])
c.LineWidth = 2.5;
set(gca,'FontSize',28,'lineWidth',2);
hold on
box on
for i=1:length(ye)
    if i==14
        hold on
        text(westindex_annualmean(i)-1,m_z500_ano_annual(i)-60,num2str(ye(i)),'FontSize',22,'fontname','Arial','Color','r');
    else
        hold on
        text(westindex_annualmean(i)-1,m_z500_ano_annual(i)-60,num2str(ye(i)),'FontSize',22,'fontname','Arial');
    end
    
end
set(gca,'tickdir','out')
box on
set(gca,'linewidth',3,'fontname','Arial')
