clear all
close all
clc
load Figure_5d.mat
[r22 p22]=corr_s(westindex_annualmean,m_z500_ano_annual,0.95)
coday=year_JA(2,:);
coday(coday==0)=[];
sz=coday.*40;
ye=year_JA(1,:);
ye(year_JA(2,:)==0)=[];
figure(1)
set(gcf,'unit','centimeters','position',[1,2,30,25])
for i=1:14
    scatter(westindex_annualmean(i),m_z500_ano_annual(i),sz(i), filledcolor(i,:),'filled');
    hold on
end
xlabel('WPSH west extension index (W/m^2)','FontSize',24)
ylabel('Z500 (gpm)','FontSize',24)
xlim([90 130])
str=get(gca,'xticklabel');
strtxt=strcat(str,'°E');
set(gca,'xticklabel',strtxt);
colormap(red_5colormat)
c = colorbar('Ticks',[0:0.2:1],...
         'TickLabels',[0:0.2:1])
c.LineWidth = 2;
set(gca,'FontSize',18,'lineWidth',2);
hold on
box on
for i=1:length(ye)
    if i==14
        hold on
        text(westindex_annualmean(i)-1,m_z500_ano_annual(i)-60,num2str(ye(i)),'FontSize',18,'fontname','Arial','Color','r');
    else
        hold on
        text(westindex_annualmean(i)-1,m_z500_ano_annual(i)-60,num2str(ye(i)),'FontSize',18,'fontname','Arial');
    end
    
end
set(gca,'tickdir','out')
box on
set(gca,'linewidth',3,'fontname','Arial')
