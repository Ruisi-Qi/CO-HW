%% SSR 
clc
clear all
close all
load('Figure_4c.mat')
%%
figure(1)
subplot(121)
m_proj('Equidistant Cylindrical','lon',[90 130],'lat',[20 40]);
m_contourf(X,Y,ssr_combine',[-1500:1:1500],'linestyle','none');
set(gca,'FontSize',28);
set(gca,'linewidth',2.5);
colormap(mycmap)
hold on
shading flat
m_grid('linestyle','none','xaxisloc','bottom','yaxisloc','left','fontsize',28,...
'xtick',[90:10:130],'Xticklabel',[90:10:130],...
'ytick',[20:5:40],'Yticklabel',[],'box','on','fontname','Arial');
m_coast('linewidth',2,'color','k');
caxis([-1500 1500]);
%dot
hold on
clear a aa
aa=abs(ssr_combine)-ssr_combine_stderror;
a=find(aa'>0);
m_plot(X(a),Y(a),'.','MarkerEdgeColor','k','MarkerSize',1.5);
%
hold on
m_box(115,128,27,35,'k',1.5)
set(gca,'FontSize',28);
set(gca,'linewidth',2.5)
box on

