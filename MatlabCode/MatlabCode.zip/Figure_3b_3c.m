clc
clear all
close all
load('Figure_2b_2c.mat')
figure(1)
set(gcf,'unit','centimeters','position',[0.08,5,50,19])
subplot(211)
mhw_bar(1,:)=year_co_mhw_inten;
mhw_bar(2,:)= year_single_mhw_inten_coyear;
b=bar(1:41,mhw_bar');
set(b(1),'FaceColor','r','EdgeColor','none');
set(b(2),'FaceColor',[0.5 0.5 0.5],'EdgeColor','none');
ylabel('MHW mean intensity (\circC)')    
box on
set(gca,'xaxisLocation','bottom','xlim',[0 42]);

cotick={'1983','1994','1998','2001','2004','2005','2006','2007','2013','2016','2017','2018','2020','2022'};
set(gca,'xtick',yr,'Xticklabel',[]);
set(gca,'ytick',[0.5:0.5:2.5],'Yticklabel',[0.5:0.5:2.5]);
ylim([0.5 2.5])
set(gca,'FontSize',24)
set(gca,'linewidth',2.5,'fontangle','oblique','fontname','Arial')%,'fontname','Times New Roman'

clear b
subplot(212)
aw_bar(1,:)=year_co_aw_inten;
aw_bar(2,:)= year_single_aw_inten_coyear;

b=bar(1:41,aw_bar');
set(b(1),'FaceColor','r','EdgeColor','none');
set(b(2),'FaceColor',[0.5 0.5 0.5],'EdgeColor','none');
ylabel('THW mean intensity (\circC)')    
box on
set(gca,'xaxisLocation','bottom','xlim',[0 42]);
cotick={'1983','1994','1998','2001','2004','2005','2006','2007','2013','2016','2017','2018','2020','2022'};
set(gca,'xtick',yr,'Xticklabel',cotick);
set(gca,'ytick',[2:0.5:6],'Yticklabel',[2:0.5:6]);
ylim([2 6])
set(gca,'FontSize',24)
set(gca,'linewidth',2.5,'fontangle','oblique','fontname','Arial')%,'fontname','Times New Roman'
















%