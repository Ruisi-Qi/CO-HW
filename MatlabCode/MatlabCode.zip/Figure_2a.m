clc
clear all
close all
load('Figure_2a.mat')
m_proj('Equidistant Cylindrical','lon',[90 130],'lat',[20 40]);
m_contourf(X,Y,z500_ano_annual_2022',[-2000:1:2000],'linestyle','none');
hold on
shading flat
set(gca,'FontSize',24);
set(gca,'linewidth',2);
colormap(mycmap)
hold on
caxis([-1500 1500]);
hold on
m_box(115,128,27,35,'k',1.5)
hold on
m_contour(X,Y,z500_annual_2022',[5880 5880],'LineColor',[0.72 0.27 1],'linewidth',2);
m_grid('linestyle','none','xaxisloc','bottom','yaxisloc','left','fontsize',24,...
'xtick',[90:10:130],'Xticklabel',[90:10:130],...
'ytick',[20:5:40],'Yticklabel',[20:5:40],'box','on','fontname','Arial');
m_coast('linewidth',2,'color','k');
% c=colorbar('vertical','fontname','Arial');
set(c,'fontsize',20,'linewidth',2)
set(gca,'FontSize',24);
set(gca,'linewidth',2)
box on